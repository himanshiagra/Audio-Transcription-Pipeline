from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_unsupported_file():
    r = client.post("/v1/transcriptions",
                    files={"file": ("bad.exe", b"not audio", "application/octet-stream")})
    assert r.status_code == 415
