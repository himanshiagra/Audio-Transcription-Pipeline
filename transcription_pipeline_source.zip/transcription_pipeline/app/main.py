import json
import os
import uuid
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from faster_whisper import WhisperModel

DATA = Path(os.getenv("TRANSCRIPTION_DATA_DIR", "data"))
AUDIO = DATA / "audio"
RESULTS = DATA / "results"
AUDIO.mkdir(parents=True, exist_ok=True)
RESULTS.mkdir(parents=True, exist_ok=True)
MAX_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", 100 * 1024 * 1024))
ALLOWED = {".wav", ".mp3", ".m4a", ".mp4", ".webm", ".ogg", ".flac"}
app = FastAPI(title="Timestamped Transcription API")
_model = None


def get_model():
    global _model
    if _model is None:
        _model = WhisperModel(
            os.getenv("WHISPER_MODEL", "base"),
            device=os.getenv("WHISPER_DEVICE", "cpu"),
            compute_type=os.getenv("WHISPER_COMPUTE_TYPE", "int8"),
        )
    return _model


def write_json(path, payload):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def transcribe(path):
    segments, info = get_model().transcribe(str(path), beam_size=5, vad_filter=True)
    items = [{"start": round(float(s.start), 3),
              "end": round(float(s.end), 3), "text": s.text.strip()}
             for s in segments]
    return {"language": info.language,
            "language_probability": round(float(info.language_probability), 4),
            "text": " ".join(x["text"] for x in items).strip(),
            "segments": items}


def process_job(job_id, path):
    target = RESULTS / f"{job_id}.json"
    try:
        write_json(target, {"job_id": job_id, "status": "processing"})
        write_json(target, {"job_id": job_id, "status": "completed",
                            "audio_file": path.name, **transcribe(path)})
    except Exception as exc:
        write_json(target, {"job_id": job_id, "status": "failed",
                            "audio_file": path.name,
                            "error": type(exc).__name__})


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/v1/transcriptions", status_code=202)
async def create_transcription(background_tasks: BackgroundTasks,
                               file: UploadFile = File(...)):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED:
        raise HTTPException(415, "Unsupported audio format")
    job_id = str(uuid.uuid4())
    path = AUDIO / f"{job_id}{suffix}"
    size = 0
    try:
        with path.open("wb") as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_BYTES:
                    raise HTTPException(413, "Upload exceeds configured size limit")
                out.write(chunk)
    except Exception:
        path.unlink(missing_ok=True)
        raise
    finally:
        await file.close()

    write_json(RESULTS / f"{job_id}.json",
               {"job_id": job_id, "status": "queued", "audio_file": path.name})
    background_tasks.add_task(process_job, job_id, path)
    return {"job_id": job_id, "status": "queued"}


@app.get("/v1/transcriptions/{job_id}")
def get_transcription(job_id: str):
    if not all(c.isalnum() or c == "-" for c in job_id):
        raise HTTPException(400, "Invalid job ID")
    path = RESULTS / f"{job_id}.json"
    if not path.exists():
        raise HTTPException(404, "Job not found")
    return json.loads(path.read_text(encoding="utf-8"))
